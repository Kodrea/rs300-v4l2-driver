#!/bin/bash
# Test reload of rs300 driver with better error handling

echo "========================================"
echo "RS300 Driver Reload Test"
echo "========================================"
echo ""

echo "Step 1: Clearing dmesg buffer..."
sudo dmesg -C

echo "Step 2: Removing old driver (forced)..."
sudo rmmod -f rs300 2>/dev/null || echo "Driver not loaded or couldn't remove"
sleep 1

echo "Step 3: Loading new driver..."
sudo insmod rs300.ko
LOAD_STATUS=$?

echo ""
echo "Step 4: Checking load status..."
if [ $LOAD_STATUS -eq 0 ]; then
    echo "✓ Driver loaded successfully"
else
    echo "✗ Driver load failed with status: $LOAD_STATUS"
fi

echo ""
echo "Step 5: Checking lsmod..."
lsmod | grep rs300

echo ""
echo "Step 6: Checking for /dev/v4l-subdev2..."
if [ -e "/dev/v4l-subdev2" ]; then
    echo "✓ /dev/v4l-subdev2 exists"
else
    echo "✗ /dev/v4l-subdev2 NOT found"
fi

echo ""
echo "Step 7: Recent kernel messages..."
dmesg | tail -40

echo ""
echo "Step 8: Checking for WARNING messages..."
if dmesg | grep -q "WARNING"; then
    echo "⚠ WARNINGs found:"
    dmesg | grep -i "warning" | head -5
else
    echo "✓ No WARNINGs found"
fi

echo ""
echo "Step 9: Checking for autoshutter controls..."
if [ -e "/dev/v4l-subdev2" ]; then
    echo "Listing autoshutter controls:"
    v4l2-ctl -d /dev/v4l-subdev2 --list-ctrls 2>/dev/null | grep -i auto || echo "No autoshutter controls found"
else
    echo "Cannot list controls - device not found"
fi

echo ""
echo "========================================"
echo "Test complete"
echo "========================================"
