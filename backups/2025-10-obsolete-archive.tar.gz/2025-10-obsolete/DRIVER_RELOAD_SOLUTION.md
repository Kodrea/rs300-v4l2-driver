# RS300 Driver Reload Without Reboot - SOLVED

**Status**: ✅ FIXED
**Date**: October 26, 2025
**Fix**: Added regulator disable to `rs300_remove()` function

---

## Problem Summary

Previously, after unloading the RS300 driver with `rmmod rs300`, the module could not be reloaded with `modprobe rs300` without a full system reboot. The camera would fail to initialize properly.

### Root Cause

The `rs300_remove()` function was missing a critical cleanup step: **disabling the power regulators**.

When the driver was unloaded:
- V4L2 subsystem was cleaned up ✓
- Media entity was removed ✓
- Controls were freed ✓
- **BUT** - The 2.8V/1.8V regulators remained ENABLED ✗

When `modprobe` reloaded the driver:
- `rs300_probe()` tried to enable already-enabled regulators
- This left the camera hardware in an undefined state
- I2C communication and initialization failed

### The Fix

**File**: `rs300.c`
**Function**: `rs300_remove()` (lines 3003-3019)
**Change**: Added `regulator_bulk_disable()` call

```c
static void rs300_remove(struct i2c_client *client)
{
    struct v4l2_subdev *sd = i2c_get_clientdata(client);
    struct rs300 *rs300 = to_rs300(sd);

    v4l2_async_unregister_subdev(sd);
    media_entity_cleanup(&sd->entity);
    rs300_free_controls(rs300);

    /* NEW: Disable regulators to ensure clean power state for module reload */
    regulator_bulk_disable(rs300_NUM_SUPPLIES, rs300->supplies);
    dev_info(&client->dev, "RS300 regulators disabled, driver removed\n");
}
```

---

## How to Reload the Driver (Without Reboot)

### Quick Method

```bash
# Unload driver
sudo rmmod rs300

# Wait a moment
sleep 1

# Reload driver
sudo modprobe rs300

# Reconfigure media pipeline
cd ~/rs300-v4l2-driver
./configure_media.sh

# Test camera
v4l2-ctl -d /dev/v4l-subdev2 --list-ctrls
```

### Automated Test Script

```bash
cd ~/rs300-v4l2-driver
./test_driver_reload.sh
```

The test script performs a complete reload cycle and verifies:
- Driver unloads cleanly
- Regulators are disabled (checks dmesg)
- Driver reloads successfully
- Camera hardware is functional
- I2C communication works
- Media controller entity present
- V4L2 controls accessible

---

## What Gets Reset on Reload

### ✅ Hardware Reset
- Power regulators disabled then re-enabled (full power cycle)
- Camera firmware reinitialized
- I2C communication reset
- MIPI CSI-2 interface reinitialized

### ✅ Driver State Reset
- V4L2 subdevice re-registered
- Media entity recreated
- All V4L2 controls reset to defaults
- Streaming state cleared

### ⚠️ NOT Reset
- Device tree overlay (stays loaded)
- I2C device node `/sys/bus/i2c/devices/10-003c` (persists)
- Media controller pipeline configuration (must run `configure_media.sh`)

---

## Development Workflow

### Before This Fix
```bash
# Make code changes
nano rs300.c

# Build
make clean && make

# Install
sudo make install

# Test - REQUIRED REBOOT!
sudo reboot
# ... wait 60+ seconds ...
./configure_media.sh
./test_controls.sh
```

**Time**: ~2-3 minutes per test cycle

### After This Fix
```bash
# Make code changes
nano rs300.c

# Build
make clean && make

# Install
sudo cp rs300.ko /lib/modules/$(uname -r)/updates/dkms/
sudo depmod -a

# Reload driver (NO REBOOT!)
sudo rmmod rs300
sudo modprobe rs300

# Reconfigure and test
./configure_media.sh
./test_controls.sh
```

**Time**: ~10-15 seconds per test cycle

**Speed improvement**: **10-15x faster** development iteration!

---

## Verification

After reload, verify everything works:

```bash
# 1. Driver loaded
lsmod | grep rs300
# Expected: rs300 module listed

# 2. I2C communication
i2cdetect -y 10
# Expected: UU at address 0x3c

# 3. Media controller
media-ctl -d /dev/media2 -p | grep rs300
# Expected: rs300 10-003c entity present

# 4. V4L2 controls
v4l2-ctl -d /dev/v4l-subdev2 --list-ctrls
# Expected: 17 controls listed

# 5. Quick functional test
./test_controls.sh --quick
# Expected: All tests pass
```

---

## Technical Details

### Why Regulator Disable is Critical

The RS300 uses three power regulators:
- **VANA**: 2.8V analog power
- **VDIG**: 1.8V digital I/O power
- **VDDL**: 1.8V digital core power

These are managed by the Linux regulator framework. When enabled:
```c
regulator_bulk_enable(rs300_NUM_SUPPLIES, rs300->supplies);
```

They remain enabled until explicitly disabled:
```c
regulator_bulk_disable(rs300_NUM_SUPPLIES, rs300->supplies);
```

### What Happens Without Disable

**Sequence without fix**:
1. Driver loads → regulators enabled → camera powered on
2. `rmmod rs300` → driver unloads → **regulators STILL ENABLED**
3. `modprobe rs300` → tries to enable already-enabled regulators
4. Regulator framework gets confused
5. Camera in undefined power state
6. I2C communication fails

**Sequence with fix**:
1. Driver loads → regulators enabled → camera powered on
2. `rmmod rs300` → regulators disabled → camera powered off cleanly
3. `modprobe rs300` → regulators enabled fresh → camera boots normally
4. Everything works!

### Device Tree Note

The I2C device at `10-003c` is created by the device tree overlay and persists across driver reload. This is normal and expected behavior. The fix ensures the *hardware* is in a clean state when the driver re-binds to this persistent device node.

---

## Comparison with Reference Drivers

### IMX219 / IMX477 / OV5647

All reference Raspberry Pi camera drivers use **runtime PM** (power management) framework:

```c
static void imx219_remove(struct i2c_client *client)
{
    // ... cleanup ...

    // Runtime PM: ensures power off
    pm_runtime_disable(&client->dev);
    if (!pm_runtime_status_suspended(&client->dev))
        imx219_power_off(&client->dev);
    pm_runtime_set_suspended(&client->dev);
}
```

### RS300 Approach

RS300 takes a simpler approach without runtime PM:

```c
static void rs300_remove(struct i2c_client *client)
{
    // ... cleanup ...

    // Direct regulator disable
    regulator_bulk_disable(rs300_NUM_SUPPLIES, rs300->supplies);
}
```

**Both achieve the same goal**: Clean power-off during driver removal.

**RS300 choice**: Simpler, no runtime PM overhead, sufficient for this camera.

---

## Future Enhancements

### Optional: Add Runtime PM

If runtime PM is desired for power-saving features:

```c
static const struct dev_pm_ops rs300_pm_ops = {
    SET_RUNTIME_PM_OPS(rs300_power_off, rs300_power_on, NULL)
};

static struct i2c_driver rs300_i2c_driver = {
    .driver = {
        .name = DRIVER_NAME,
        .of_match_table = of_match_ptr(rs300_of_match),
        .pm = &rs300_pm_ops,  // Add runtime PM
    },
    .probe = rs300_probe,
    .remove = rs300_remove,
};
```

This would enable:
- Auto-suspend during idle
- Power savings
- Camera sleep mode integration

**Status**: Not currently needed, simple approach works well.

---

## Related Issues

### Device Tree Overlay Persistence

The device tree overlay loaded via `/boot/firmware/config.txt`:
```
dtoverlay=rs300
```

Creates a persistent I2C device that survives driver reload. This is by design and not a bug. See research in `external-docs/` for detailed analysis of alternative approaches.

### Camera Sleep Command

The RS300 has a separate I2C sleep command (`0x10 0x10 0x48`) that puts the camera in low-power mode without cutting power. This is different from the regulator disable and is used for runtime power saving, not driver reload.

---

## Testing Results

**Test Date**: October 26, 2025
**System**: Raspberry Pi 5, Kernel 6.12.25+rpt-rpi-2712
**Result**: ✅ SUCCESS

**Test Sequence**:
1. ✅ Driver loads at boot
2. ✅ `rmmod rs300` - clean unload with regulator disable
3. ✅ `modprobe rs300` - successful reload
4. ✅ I2C communication functional
5. ✅ Media controller entity present
6. ✅ V4L2 controls working
7. ✅ Streaming functional after `configure_media.sh`

**Reload Time**: ~3 seconds (vs 60+ seconds for reboot)

---

## Conclusion

The driver reload issue has been completely solved with a simple one-line fix: disabling regulators in the remove function. This enables rapid development iteration without reboots.

**Key Takeaway**: When writing kernel drivers, always ensure all hardware resources (GPIOs, clocks, regulators) are properly disabled during cleanup, not just freed.

---

**See Also**:
- `rs300.c` lines 3003-3019 (implementation)
- `test_driver_reload.sh` (automated test)
- `external-docs/DOCUMENTATION_SOURCES.md` (research findings)
