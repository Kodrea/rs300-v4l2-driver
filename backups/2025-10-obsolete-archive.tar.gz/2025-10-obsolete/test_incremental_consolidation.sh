#!/bin/bash
# ⚠️ OBSOLETE - DO NOT USE (2025-10-24)
# This script was created for incremental testing of code consolidation which was ABANDONED.
# See: .claude/lessons-learned/002-consolidation-kernel-crash.md
#
# Original purpose: Incremental Testing Script for RS300 Consolidation
# Tests each phase separately using proper setup.sh methodology
#
# WARNING: This script MUST NOT be run - consolidation causes kernel crashes
# Preserved for historical reference only

set -e  # Exit on error

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

#=============================================================================
# Helper Functions
#=============================================================================

log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

verify_probe() {
    log_info "Verifying probe succeeded..."

    # Check device exists
    if [ ! -e /dev/v4l-subdev2 ]; then
        log_error "Camera device /dev/v4l-subdev2 NOT FOUND - probe failed!"
        log_error "Check dmesg for Oops/errors:"
        dmesg | tail -50 | grep -E "rs300|Oops|BUG"
        return 1
    fi

    # Check dmesg for probe messages
    if ! dmesg | tail -30 | grep -q "rs300"; then
        log_warning "No recent rs300 messages in dmesg"
    fi

    # Check for errors
    if dmesg | tail -50 | grep -E "Oops|BUG.*rs300"; then
        log_error "Kernel Oops detected! System may be unstable."
        log_error "STOP HERE - Reboot before continuing"
        return 1
    fi

    log_success "Probe succeeded - /dev/v4l-subdev2 exists"
    return 0
}

test_basic_functionality() {
    log_info "Testing basic functionality..."

    # Test control access
    if ! v4l2-ctl -d /dev/v4l-subdev2 --list-ctrls > /dev/null 2>&1; then
        log_error "Cannot access camera controls"
        return 1
    fi

    log_success "Camera controls accessible"
    return 0
}

pause_for_review() {
    echo ""
    log_warning "CHECKPOINT: Review the output above"
    read -p "Press Enter to continue, or Ctrl+C to abort..."
    echo ""
}

#=============================================================================
# Phase 0: Verify Baseline (HEAD)
#=============================================================================

test_phase_0_baseline() {
    echo "=========================================="
    echo "PHASE 0: Verify HEAD (baseline)"
    echo "=========================================="
    log_info "This verifies the committed code loads cleanly"
    echo ""

    log_info "Current git state:"
    git status --short
    echo ""

    log_info "Unloading old driver..."
    sudo rmmod rs300 || log_warning "Driver not loaded or failed to unload"
    sleep 1

    log_info "Building and installing with setup.sh..."
    ./setup.sh << EOF
n
EOF

    log_info "Loading driver..."
    sudo modprobe rs300

    if ! verify_probe; then
        log_error "PHASE 0 FAILED - HEAD is broken!"
        log_error "This should never happen - investigate immediately"
        return 1
    fi

    if ! test_basic_functionality; then
        log_error "PHASE 0 FAILED - controls not working"
        return 1
    fi

    log_success "PHASE 0 PASSED - HEAD loads and works correctly"
    pause_for_review
    return 0
}

#=============================================================================
# Phase 1: Test Consolidation (Phases 1.1 + 2)
#=============================================================================

test_phase_1_consolidation() {
    echo "=========================================="
    echo "PHASE 1: Test Consolidation (1.1 + 2)"
    echo "=========================================="
    log_info "Testing: rs300_send_command READ support + 3 consolidated GET functions"
    echo ""

    log_info "Applying consolidation changes from stash..."
    # This requires manual application - just Phase 1.1 + 2
    log_warning "TODO: Need to manually cherry-pick only consolidation changes"
    log_warning "Exclude Phase 3.1 (rs300_remove) and Phase 3.2 (log reduction)"

    pause_for_review

    log_info "Unloading driver..."
    sudo rmmod rs300
    sleep 1

    log_info "Building with setup.sh..."
    ./setup.sh << EOF
n
EOF

    log_info "Loading driver..."
    sudo modprobe rs300

    if ! verify_probe; then
        log_error "PHASE 1 FAILED - Probe crashed!"
        log_error "BUG is in Phase 1.1 or Phase 2 (consolidation)"
        log_error "Review rs300_send_command changes and GET function consolidations"
        dmesg > /tmp/phase1_failure_$(date +%Y%m%d_%H%M%S).log
        return 1
    fi

    if ! test_basic_functionality; then
        log_error "PHASE 1 FAILED - Controls not working"
        return 1
    fi

    log_info "Testing consolidated functions specifically..."
    ./test_consolidated_code.sh

    if [ $? -ne 0 ]; then
        log_error "PHASE 1 FAILED - Consolidated functions broken"
        return 1
    fi

    log_success "PHASE 1 PASSED - Consolidation works!"
    pause_for_review
    return 0
}

#=============================================================================
# Phase 2: Test rs300_remove Enhancement (Phase 3.1)
#=============================================================================

test_phase_2_remove() {
    echo "=========================================="
    echo "PHASE 2: Test rs300_remove Enhancement"
    echo "=========================================="
    log_info "Testing: Enhanced rs300_remove with streaming check"
    echo ""

    log_info "Applying Phase 3.1 changes (rs300_remove enhancement)..."
    log_warning "TODO: Manually apply rs300_remove changes"

    pause_for_review

    log_info "Rebuilding..."
    sudo rmmod rs300
    sleep 1
    ./setup.sh << EOF
n
EOF
    sudo modprobe rs300

    if ! verify_probe; then
        log_error "PHASE 2 FAILED - Probe crashed!"
        log_error "BUG is in Phase 3.1 (rs300_remove)"
        return 1
    fi

    log_info "Testing removal while idle..."
    sudo rmmod rs300
    if ! dmesg | tail -10 | grep -q "Removing RS300 driver"; then
        log_warning "Expected removal message not found"
    fi
    if ! dmesg | tail -10 | grep -q "removed successfully"; then
        log_warning "Expected success message not found"
    fi
    log_success "Removal while idle works"

    log_info "Reloading for streaming test..."
    sudo modprobe rs300
    ./configure_media.sh

    log_info "Testing removal during streaming..."
    v4l2-ctl -d /dev/video0 --set-fmt-video=width=640,height=512 \
             --stream-mmap --stream-count=300 > /dev/null 2>&1 &
    STREAM_PID=$!
    sleep 3

    log_info "Removing module while streaming (PID: $STREAM_PID)..."
    sudo rmmod rs300

    if dmesg | tail -20 | grep -q "Stopping active streaming before removal"; then
        log_success "Streaming was stopped before removal"
    else
        log_warning "Expected streaming stop message not found"
    fi

    # Kill streaming process if still alive
    kill -9 $STREAM_PID 2>/dev/null || true

    log_success "PHASE 2 PASSED - rs300_remove enhancement works!"
    pause_for_review
    return 0
}

#=============================================================================
# Phase 3: Test Log Reduction (Phase 3.2)
#=============================================================================

test_phase_3_logs() {
    echo "=========================================="
    echo "PHASE 3: Test Log Reduction"
    echo "=========================================="
    log_info "Testing: dev_info → dev_dbg conversion"
    echo ""

    log_info "Applying Phase 3.2 changes (log reduction)..."
    log_warning "TODO: Manually apply log reduction changes"

    pause_for_review

    log_info "Rebuilding..."
    ./setup.sh << EOF
n
EOF
    sudo modprobe rs300

    if ! verify_probe; then
        log_error "PHASE 3 FAILED - Probe crashed!"
        log_error "BUG is in Phase 3.2 (log reduction)"
        return 1
    fi

    log_info "Testing log volume..."
    sudo dmesg -C
    v4l2-ctl -d /dev/v4l-subdev2 -c brightness=75
    LOG_COUNT=$(dmesg | wc -l)

    log_info "Log lines after brightness change: $LOG_COUNT"
    if [ $LOG_COUNT -lt 10 ]; then
        log_success "Log volume reduced (< 10 lines)"
    else
        log_warning "Log volume still high ($LOG_COUNT lines)"
    fi

    log_success "PHASE 3 PASSED - Log reduction works!"
    pause_for_review
    return 0
}

#=============================================================================
# Phase 4: Full Integration Test
#=============================================================================

test_phase_4_integration() {
    echo "=========================================="
    echo "PHASE 4: Full Integration Test"
    echo "=========================================="
    log_info "Testing: All phases together"
    echo ""

    log_info "Running full control test suite..."
    ./configure_media.sh
    ./test_controls.sh

    if [ $? -ne 0 ]; then
        log_error "PHASE 4 FAILED - Full test suite failed"
        return 1
    fi

    log_success "PHASE 4 PASSED - All tests successful!"
    return 0
}

#=============================================================================
# Main Execution
#=============================================================================

main() {
    echo "=========================================="
    echo "RS300 INCREMENTAL CONSOLIDATION TESTING"
    echo "=========================================="
    echo ""
    log_warning "This script will test each consolidation phase separately"
    log_warning "CRITICAL: Watch for kernel Oops at each step"
    log_warning "If system crashes, reboot before continuing"
    echo ""

    pause_for_review

    # Phase 0: Baseline
    if ! test_phase_0_baseline; then
        log_error "Baseline test failed - stopping"
        exit 1
    fi

    # Phase 1: Consolidation
    log_warning "Phase 1 requires manual cherry-picking of changes"
    log_warning "Apply ONLY Phase 1.1 + 2 (consolidation) from stash"
    read -p "Press Enter when changes are applied, or Ctrl+C to skip..."

    if ! test_phase_1_consolidation; then
        log_error "Consolidation test failed - THIS IS THE BUG"
        log_error "Review Phase 1.1 and Phase 2 changes"
        exit 1
    fi

    # Phase 2: rs300_remove enhancement
    log_warning "Phase 2 requires applying rs300_remove changes"
    read -p "Press Enter when changes are applied, or Ctrl+C to skip..."

    if ! test_phase_2_remove; then
        log_error "Remove enhancement test failed"
        exit 1
    fi

    # Phase 3: Log reduction
    log_warning "Phase 3 requires applying log reduction changes"
    read -p "Press Enter when changes are applied, or Ctrl+C to skip..."

    if ! test_phase_3_logs; then
        log_error "Log reduction test failed"
        exit 1
    fi

    # Phase 4: Integration
    if ! test_phase_4_integration; then
        log_error "Integration test failed"
        exit 1
    fi

    echo ""
    echo "=========================================="
    log_success "ALL TESTS PASSED!"
    echo "=========================================="
    log_info "Ready to commit changes"
    log_info "Run: git add rs300.c CLAUDE.md"
    log_info "Run: git commit -m 'refactor: Complete code consolidation'"
    echo ""
}

# Run main
main "$@"
