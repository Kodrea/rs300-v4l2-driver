# ⚠️ OBSOLETE - Testing Instructions: Incremental Consolidation Validation

**Date Created**: 2024-10-24
**Date Obsoleted**: 2025-10-24
**Status**: ❌ **DO NOT USE - CONSOLIDATION ABANDONED**

This document was created for testing code consolidation which was subsequently ABANDONED.
See: `.claude/lessons-learned/002-consolidation-kernel-crash.md` for why.

**Preserved for historical reference only.**

---

# Original Instructions (For Historical Reference)

**Original Status**: System rebooted, baseline verified working
**Original State**: rs300.c changes stashed, HEAD checked out (2783 lines)
**Stash**: "Consolidation work - all phases (pre-testing)"

---

## Quick Summary (Original)

Testing was needed for consolidation work incrementally because:
1. The consolidated code caused kernel Oops during module load
2. Need to identify which phase caused the crash
3. Must use `./setup.sh` (not manual module copy) per lessons-learned

**Result**: Phase 1.1 testing confirmed the bug. Consolidation abandoned.

---

## Phase 0: Verify HEAD Works (REQUIRED FIRST)

**Purpose**: Establish that committed code loads cleanly

```bash
# 1. Unload old driver
sudo rmmod rs300

# 2. Build and install HEAD with setup.sh
./setup.sh
# When prompted about auto-config, select 'n'

# 3. Load driver
sudo modprobe rs300

# 4. CRITICAL CHECK: Did probe succeed?
ls -la /dev/v4l-subdev2
# Should exist - if not, probe failed

dmesg | tail -30 | grep rs300
# Check for Oops/BUG - if found, STOP and investigate

# 5. Test functionality
v4l2-ctl -d /dev/v4l-subdev2 --list-ctrls
# Should show all 11 controls

# 6. Quick test
./test_controls.sh --quick
```

**Expected**: All checks pass, no Oops, controls work

**If this fails**: HEAD is broken (shouldn't happen) - investigate

---

## Understanding The Problem

From the Oops we saw earlier:
- Crash location: `rs300_probe+0x4f0`
- Device not created: `/dev/v4l-subdev2` missing
- Module loaded but non-functional

**Root cause unknown** - could be:
- Phase 1.1: rs300_send_command READ support changes
- Phase 2: Consolidated GET functions (brightness, colormap, yuv_format)
- Phase 3.1: rs300_remove enhancement (unlikely to affect probe)
- Phase 3.2: Log reduction (could hide critical initialization)

---

## Recommended Testing Approach

### Option A: Test Everything at Once (Risky but Fast)

```bash
# Apply all changes
git stash pop

# Build and test
sudo rmmod rs300
./setup.sh
sudo modprobe rs300

# Check for Oops immediately
dmesg | tail -50
ls /dev/v4l-subdev2

# If crashes again: We know bug is in our changes, proceed to Option B
# If works: Run full tests and commit
```

**Time**: 5 minutes
**Risk**: If it crashes, still don't know which phase is the problem

---

### Option B: Incremental Testing (Safe but Slower)

This is what the automated script does:

#### Step 1: Apply ONLY Phase 1.1 + 2 (Consolidation)

**Changes to apply manually**:
1. Enhanced `rs300_send_command()` with result_buffer/result_len params
2. Consolidated `rs300_get_brightness()` (130→24 lines)
3. Consolidated `rs300_get_colormap()` (88→21 lines)
4. Consolidated `rs300_set_yuv_format()` (70→17 lines)

**DO NOT apply**:
- rs300_remove changes (Phase 3.1)
- dev_info→dev_dbg changes (Phase 3.2)

```bash
# Extract just consolidation changes from stash
git stash show -p > /tmp/all_changes.patch

# Manually edit rs300.c to apply only consolidation sections
# OR cherry-pick specific functions from stash

# Test
sudo rmmod rs300
./setup.sh
sudo modprobe rs300

# Check
ls /dev/v4l-subdev2    # Should exist
./test_consolidated_code.sh  # Should pass
```

**If this crashes**: BUG is in Phase 1.1 or 2 - need to investigate consolidation
**If this works**: Continue to Step 2

#### Step 2: Add Phase 3.1 (rs300_remove enhancement)

**Changes to apply**:
- Enhanced rs300_remove() with streaming check, power-off

```bash
# Apply rs300_remove changes

# Test
sudo rmmod rs300
./setup.sh
sudo modprobe rs300

# Test removal scenarios
sudo rmmod rs300  # Test idle removal
dmesg | tail -20  # Should see clean removal

sudo modprobe rs300
./configure_media.sh
# Start streaming, then remove
v4l2-ctl --stream-mmap --stream-count=300 &
sleep 2
sudo rmmod rs300  # Should stop streaming first
```

**If crashes**: BUG is in Phase 3.1
**If works**: Continue to Step 3

#### Step 3: Add Phase 3.2 (Log Reduction)

**Changes to apply**:
- 14 × dev_info→dev_dbg conversions

```bash
# Apply log reduction changes

# Test
sudo rmmod rs300
./setup.sh
sudo modprobe rs300

# Verify log reduction
sudo dmesg -C
v4l2-ctl -d /dev/v4l-subdev2 -c brightness=75
dmesg | wc -l  # Should be < 10
```

**If crashes**: BUG is in Phase 3.2
**If works**: All phases successful!

#### Step 4: Full Integration Test

```bash
./test_controls.sh  # All 11 controls
# Should take ~5 minutes, all should pass
```

**Time**: 30-45 minutes
**Benefit**: Know exactly which phase has the bug

---

## Automated Script Available

I've created `test_incremental_consolidation.sh` that automates the above, but:
- Requires manual change application at each phase (I couldn't automate git operations)
- Provides detailed checkpoints and verification
- Captures evidence if things fail

To use:
```bash
./test_incremental_consolidation.sh
# Follow prompts, apply changes when requested
```

---

## What To Do When You Find The Bug

### If Phase 1.1 or 2 Crashes (Consolidation)

**Likely causes**:
1. Memory corruption in rs300_send_command
2. Buffer overflow in consolidated GET functions
3. Missing initialization in result_buffer path

**Debug**:
```bash
# Check Oops location
dmesg | grep "Code:"  # Assembly instruction

# Check call stack
dmesg | grep "Call trace" -A 10

# Review changes to rs300_send_command carefully
# Focus on result_buffer handling
```

### If Phase 3.1 Crashes (rs300_remove)

**Unlikely** - removal changes shouldn't affect probe
**Unless**: Memory corruption affecting global state

### If Phase 3.2 Crashes (Log Reduction)

**Very Unlikely** - just changing log levels
**Unless**: Accidentally converted critical error check

---

## Recovery If Things Go Wrong

If you get a kernel Oops at any step:

```bash
# 1. Save evidence immediately
dmesg > /tmp/oops_$(date +%Y%m%d_%H%M%S).log

# 2. DO NOT retry - kernel state corrupted
# 3. Reboot
sudo reboot

# 4. After reboot, analyze the Oops
cat /tmp/oops_*.log

# 5. Focus investigation on the phase that failed
```

---

## My Recommendation

**Start with Option A** (test everything):
- If it works: Great! Commit and done.
- If it crashes: You've confirmed the bug exists, proceed to Option B

**Then Option B** (incremental):
- Will pinpoint exactly which phase is broken
- Can fix that specific phase
- Minimal time investment since we already know there's a bug

---

## Expected Timeline

- **Option A only**: 10 minutes (if it works)
- **Option A fails → Option B**: 45 minutes total
- **With debugging**: 1-2 hours

---

## Questions?

Check:
- `.claude/lessons-learned/001-bypass-setup-script.md` - Why we use setup.sh
- `CLAUDE.md` - "Driver Development & Testing Workflow" section
- This file's automated script section

Good luck! Document what you find.
