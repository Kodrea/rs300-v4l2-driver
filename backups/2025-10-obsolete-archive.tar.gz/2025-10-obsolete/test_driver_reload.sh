#!/bin/bash
# Test RS300 driver reload without reboot
# This script tests the regulator disable fix

set -e  # Exit on error

echo "========================================"
echo "RS300 Driver Reload Test"
echo "Testing regulator disable fix"
echo "========================================"
echo ""

# Colors
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

echo -e "${BLUE}Step 1: Verify driver currently loaded${NC}"
if lsmod | grep -q rs300; then
    echo -e "${GREEN}✓ Driver is loaded${NC}"
else
    echo -e "${RED}✗ Driver not loaded, loading it first...${NC}"
    sudo modprobe rs300
    sleep 2
fi
echo ""

echo -e "${BLUE}Step 2: Check media pipeline before unload${NC}"
media-ctl -d /dev/media2 -p | grep "rs300 10-003c" || echo "  (camera entity check)"
echo ""

echo -e "${BLUE}Step 3: Unload driver (rmmod rs300)${NC}"
echo "  Executing: sudo rmmod rs300"
sudo rmmod rs300
sleep 1
echo -e "${GREEN}✓ Driver unloaded${NC}"
echo ""

echo -e "${BLUE}Step 4: Check dmesg for regulator disable message${NC}"
echo "  Looking for: 'RS300 regulators disabled, driver removed'"
if dmesg | tail -20 | grep -q "RS300 regulators disabled"; then
    echo -e "${GREEN}✓ Regulator disable message found:${NC}"
    dmesg | tail -20 | grep "RS300 regulators disabled"
else
    echo -e "${YELLOW}⚠ Regulator disable message not found in recent dmesg${NC}"
    echo "  Last 10 dmesg lines:"
    dmesg | tail -10
fi
echo ""

echo -e "${BLUE}Step 5: Verify driver unloaded${NC}"
if lsmod | grep -q rs300; then
    echo -e "${RED}✗ Driver still loaded!${NC}"
    exit 1
else
    echo -e "${GREEN}✓ Driver successfully unloaded${NC}"
fi
echo ""

echo -e "${BLUE}Step 6: Wait 2 seconds...${NC}"
sleep 2
echo ""

echo -e "${BLUE}Step 7: Reload driver (modprobe rs300)${NC}"
echo "  Executing: sudo modprobe rs300"
sudo modprobe rs300
sleep 2
echo -e "${GREEN}✓ Driver reload command completed${NC}"
echo ""

echo -e "${BLUE}Step 8: Verify driver loaded${NC}"
if lsmod | grep -q rs300; then
    echo -e "${GREEN}✓ Driver successfully loaded${NC}"
    lsmod | grep rs300 | head -1
else
    echo -e "${RED}✗ Driver failed to load!${NC}"
    echo "  Checking dmesg for errors..."
    dmesg | tail -20
    exit 1
fi
echo ""

echo -e "${BLUE}Step 9: Check probe messages in dmesg${NC}"
echo "  Looking for successful probe..."
if dmesg | tail -30 | grep -q "rs300.*probe"; then
    echo -e "${GREEN}✓ Probe messages found${NC}"
    dmesg | tail -30 | grep "rs300" | tail -5
else
    echo -e "${YELLOW}⚠ No recent probe messages${NC}"
fi
echo ""

echo -e "${BLUE}Step 10: Verify I2C device${NC}"
if i2cdetect -y 10 | grep -q "UU"; then
    echo -e "${GREEN}✓ I2C device detected (UU at 0x3c)${NC}"
    i2cdetect -y 10 | grep "30:"
else
    echo -e "${RED}✗ I2C device not detected${NC}"
fi
echo ""

echo -e "${BLUE}Step 11: Check media controller${NC}"
if media-ctl -d /dev/media2 -p 2>/dev/null | grep -q "rs300 10-003c"; then
    echo -e "${GREEN}✓ RS300 entity found in media controller${NC}"
    media-ctl -d /dev/media2 -e "rs300 10-003c"
else
    echo -e "${RED}✗ RS300 entity not found${NC}"
fi
echo ""

echo -e "${BLUE}Step 12: List V4L2 controls${NC}"
if v4l2-ctl -d /dev/v4l-subdev2 --list-ctrls 2>/dev/null | grep -q "brightness"; then
    echo -e "${GREEN}✓ V4L2 controls accessible${NC}"
    echo "  Control count:"
    v4l2-ctl -d /dev/v4l-subdev2 --list-ctrls 2>/dev/null | grep -c "0x"
else
    echo -e "${RED}✗ V4L2 controls not accessible${NC}"
fi
echo ""

echo "========================================"
echo -e "${GREEN}✓✓✓ DRIVER RELOAD TEST COMPLETE ✓✓✓${NC}"
echo "========================================"
echo ""
echo "Summary:"
echo "  - Driver was unloaded with rmmod"
echo "  - Regulators were disabled (check Step 4)"
echo "  - Driver was reloaded with modprobe"
echo "  - Camera is functional"
echo ""
echo -e "${YELLOW}NOTE: You must still run ./configure_media.sh before streaming${NC}"
echo ""
