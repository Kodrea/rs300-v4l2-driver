# Install Autoshutter Driver - Correct Procedure

## The Right Way (Using setup.sh)

```bash
# Step 1: Install driver via DKMS (this handles everything properly)
./setup.sh

# Step 2: Reboot to load the new driver
sudo reboot

# Step 3: After reboot, test
v4l2-ctl -d /dev/v4l-subdev2 --list-ctrls | grep -i auto
```

## Why setup.sh?

The `./setup.sh` script:
- ✅ Removes old DKMS versions properly
- ✅ Builds with correct kernel headers
- ✅ Installs to the right module directory
- ✅ Handles dependencies correctly
- ✅ Regenerates initramfs if needed

## Why NOT insmod?

Using `insmod rs300.ko` directly:
- ❌ Doesn't handle DKMS versions
- ❌ Can conflict with installed modules
- ❌ May not load dependencies correctly
- ❌ Can leave system in bad state

## Current Status

Driver has been modified with:
- ✅ 3 autoshutter I2C command functions implemented
- ✅ 4 V4L2 controls defined
- ✅ Boolean control step fixed (0 instead of 1)
- ✅ All code compiles without errors

**Ready to install via setup.sh and reboot.**

## Expected Result After Reboot

If successful, you should see:

```bash
v4l2-ctl -d /dev/v4l-subdev2 --list-ctrls | grep -i auto
```

Output:
```
                autoshutter 0x00980908 (bool)   : default=0 value=0
     autoshutter_temperature 0x00980909 (int)    : min=10 max=100 step=1 default=50 value=50
   autoshutter_min_interval 0x0098090a (int)    : min=1 max=300 step=1 default=1 value=1
   autoshutter_max_interval 0x0098090b (int)    : min=1 max=600 step=1 default=120 value=120
```

## If It Still Fails

Check dmesg after reboot:
```bash
dmesg | grep -i rs300 | tail -50
dmesg | grep -i warning
```

Look for:
- Control registration warnings
- Probe failures
- I2C communication errors
