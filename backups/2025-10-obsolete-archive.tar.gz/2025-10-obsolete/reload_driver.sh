#!/bin/bash
# Reload the rs300 driver with new autoshutter controls

echo "Removing old driver..."
sudo rmmod rs300

echo "Loading new driver..."
sudo insmod rs300.ko

echo "Checking driver loaded..."
lsmod | grep rs300

echo ""
echo "Recent kernel messages:"
dmesg | tail -20

echo ""
echo "Listing all V4L2 controls:"
v4l2-ctl -d /dev/v4l-subdev2 --list-ctrls
