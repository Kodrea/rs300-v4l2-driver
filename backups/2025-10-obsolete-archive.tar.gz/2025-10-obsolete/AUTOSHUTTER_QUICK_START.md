# Autoshutter Quick Start Guide

**RS300 Thermal Camera - Sprint 1 Batch 1**

---

## ✅ Implementation Complete

3 autoshutter I2C commands implemented
4 V4L2 controls registered
Driver builds successfully

---

## 🚀 Quick Start (3 Steps)

### 1. Reload the Driver

```bash
sudo ./reload_driver.sh
```

### 2. List New Controls

```bash
v4l2-ctl -d /dev/v4l-subdev2 --list-ctrls | grep -i auto
```

### 3. Test Autoshutter

```bash
./test_autoshutter.sh
```

---

## 📋 Available Controls

| Control | Type | Range | Default | Purpose |
|---------|------|-------|---------|---------|
| `autoshutter` | Boolean | 0-1 | 0 | Enable/disable auto FFC |
| `autoshutter_temperature` | Integer | 10-100 | 50 | Temp threshold (1/32°C) |
| `autoshutter_min_interval` | Integer | 1-300 sec | 1 | Min FFC interval |
| `autoshutter_max_interval` | Integer | 1-600 sec | 120 | Max FFC interval |

---

## 🎯 Common Usage Examples

### Enable autoshutter with default settings:
```bash
v4l2-ctl -d /dev/v4l-subdev2 -c autoshutter=1
```

### Set temperature threshold to 1.56°C (value 50):
```bash
v4l2-ctl -d /dev/v4l-subdev2 -c autoshutter_temperature=50
```

### Set FFC intervals (5 sec min, 5 min max):
```bash
v4l2-ctl -d /dev/v4l-subdev2 -c autoshutter_min_interval=5
v4l2-ctl -d /dev/v4l-subdev2 -c autoshutter_max_interval=300
```

### Disable autoshutter:
```bash
v4l2-ctl -d /dev/v4l-subdev2 -c autoshutter=0
```

---

## 🔍 Verify Operation

Check kernel messages:
```bash
dmesg | tail -20 | grep -i autoshutter
```

Expected output:
```
rs300 10-003c: Setting autoshutter: ON
rs300 10-003c: Setting autoshutter param type 0 to value 50
```

---

## 📊 Temperature Threshold Conversion

| Value | Temperature | Use Case |
|-------|-------------|----------|
| 10 | 0.31°C | Very sensitive, frequent FFC |
| 30 | 0.94°C | Moderate sensitivity |
| **50** | **1.56°C** | **Default, recommended** |
| 75 | 2.34°C | Less sensitive |
| 100 | 3.12°C | Minimal FFC triggers |

---

## ⏭️ Next Steps

After successful testing:
1. Move to **Sprint 1 Batch 2**: Module Sleep Commands
2. See `I2C_COMMANDS_TO_IMPLEMENT.md` for details

---

## 📖 Full Documentation

- **Implementation Summary**: SPRINT1_BATCH1_SUMMARY.md
- **Testing Script**: test_autoshutter.sh
- **Command Reference**: I2C_COMMANDS_TO_IMPLEMENT.md (Batch 1 section)
- **Driver Analysis**: DRIVER_ANALYSIS.md

---

**Status**: ✅ Ready for hardware testing
**Build**: ✅ Compiles successfully (rs300.ko)
**Next**: Load driver and test on real hardware
