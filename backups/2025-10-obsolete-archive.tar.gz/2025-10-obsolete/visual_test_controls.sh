#!/bin/bash
# Visual Test Script for RS300 Camera Controls
# Tests specific control sequences for visual verification while streaming

# Configuration
SUBDEV="/dev/v4l-subdev2"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Print header
print_header() {
    echo -e "${BLUE}=== $1 ===${NC}"
}

# Helper function to set control
set_control() {
    local ctrl_name=$1
    local value=$2
    local description=$3

    echo -e "${YELLOW}[TEST]${NC} Setting $ctrl_name = $value ($description)"

    # Attempt to set control and check for errors
    local output=$(v4l2-ctl -d $SUBDEV -c ${ctrl_name}=${value} 2>&1)

    if echo "$output" | grep -qi "error\|invalid"; then
        echo -e "${YELLOW}[SKIP]${NC} $ctrl_name=$value not available on this camera"
        return 1
    else
        echo -e "${GREEN}[OK]${NC} $ctrl_name set to $value"
        return 0
    fi
}

# Check prerequisites
check_prerequisites() {
    print_header "RS300 Visual Control Test"

    if [ ! -e "$SUBDEV" ]; then
        echo -e "${RED}Error: $SUBDEV not found${NC}"
        echo "Please ensure driver is loaded and media pipeline is configured"
        exit 1
    fi

    if ! command -v v4l2-ctl &> /dev/null; then
        echo -e "${RED}Error: v4l2-ctl not found. Please install v4l-utils${NC}"
        exit 1
    fi

    echo -e "${GREEN}Prerequisites met${NC}"
    echo -e "${BLUE}Starting visual test sequence...${NC}\n"
}

# Main test sequence
main() {
    check_prerequisites

    # Step 1: FFC Trigger
    print_header "Step 1: FFC Trigger"
    set_control "ffc_trigger" 1 "Flat field calibration"
    echo "Waiting 3 seconds for FFC to complete..."
    sleep 3
    echo

    # Step 2: Colormap sequence (1, 10, 5, 3)
    print_header "Step 2: Colormap Sequence"
    echo "Testing colormaps: Reserved → Black Hot → Night → Ironbow"

    colormaps=(1 10 5 3)
    colormap_names=("Reserved" "Black Hot" "Night" "Ironbow")

    for i in "${!colormaps[@]}"; do
        set_control "colormap" "${colormaps[$i]}" "${colormap_names[$i]}"
        sleep 1.5
    done
    echo

    # Step 3: Brightness sequence (50, 55, 60, 65, 60, 50, 40, 35, 40, 50)
    print_header "Step 3: Brightness Sequence"
    echo "Testing brightness ramp: 50 → 65 → 35 → 50"

    brightness_values=(50 55 60 65 60 50 40 35 40 50)

    for value in "${brightness_values[@]}"; do
        set_control "brightness" "$value" "${value}%"
        sleep 0.5
    done
    echo

    # Step 4: Scene mode sequence (0, 1, 4, 5)
    print_header "Step 4: Scene Mode Sequence"
    echo "Testing scene modes (may skip if unavailable on this camera)"

    scene_modes=(0 1 4 5)
    scene_names=("Low" "Linear Stretch" "High Contrast" "Highlight")

    for i in "${!scene_modes[@]}"; do
        set_control "scene_mode" "${scene_modes[$i]}" "${scene_names[$i]}"
        sleep 1
    done
    echo

    # Step 5: Reset to defaults
    print_header "Step 5: Reset to Defaults"
    set_control "brightness" 50 "Default brightness"
    sleep 0.3
    set_control "colormap" 0 "White Hot (default)"
    sleep 0.3
    set_control "scene_mode" 3 "General Mode (default)"
    echo

    print_header "Test Complete"
    echo -e "${GREEN}All visual tests completed successfully!${NC}"
    echo "Camera controls reset to default values"
}

# Run main function
main
