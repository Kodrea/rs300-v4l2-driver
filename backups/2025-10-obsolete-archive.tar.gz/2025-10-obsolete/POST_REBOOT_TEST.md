# Post-Reboot Testing Plan

## What Happened

The driver crashed during probe, causing system instability (journald crashed). The crash occurred when registering the new autoshutter controls - v4l2_ctrl_new_custom threw warnings which likely led to a NULL pointer dereference.

## Root Cause Analysis

Reviewing the kernel warnings:
- 3 WARNINGs from v4l2_ctrl_new_custom (likely the 3 INTEGER controls)
- The BOOLEAN control's step value was wrong (was 1, should be 0) - FIXED
- But there may be additional issues with the INTEGER controls

## After Reboot - Diagnostic Steps

### Step 1: Test Current Production Driver

```bash
# After reboot, test that the OLD driver still works
sudo modprobe rs300
v4l2-ctl -d /dev/v4l-subdev2 --list-ctrls
```

This confirms the system is stable and the existing driver works.

### Step 2: Review Control Registration Order

The issue might be related to control ID conflicts or initialization order. Looking at the IDs:

**Existing:**
- CUSTOM_BASE + 1: Colormap
- CUSTOM_BASE + 2: FFC Trigger
- CUSTOM_BASE + 3: Scene Mode
- CUSTOM_BASE + 4: DDE
- CUSTOM_BASE + 5: Spatial NR
- CUSTOM_BASE + 6: Temporal NR
- CUSTOM_BASE + 7: Output Mode

**New (my additions):**
- CUSTOM_BASE + 8: Auto Shutter
- CUSTOM_BASE + 9: Auto Shutter Temperature
- CUSTOM_BASE + 10: Auto Shutter Min Interval
- CUSTOM_BASE + 11: Auto Shutter Max Interval

**Potential Issue**: Sequential IDs (8-11) registered before ID 7 (output_mode) in rs300_init_controls()

### Step 3: Try Simplified Version

Create a version with ONLY the boolean autoshutter control (not the 3 integer parameter controls) to see if that works:

```c
// Register only this one:
rs300->autoshutter = v4l2_ctrl_new_custom(ctrl_hdlr, &autoshutter_ctrl, NULL);

// Comment out these three:
// rs300->autoshutter_temp = v4l2_ctrl_new_custom(ctrl_hdlr, &autoshutter_temp_ctrl, NULL);
// rs300->autoshutter_min_interval = v4l2_ctrl_new_custom(ctrl_hdlr, &autoshutter_min_interval_ctrl, NULL);
// rs300->autoshutter_max_interval = v4l2_ctrl_new_custom(ctrl_hdlr, &autoshutter_max_interval_ctrl, NULL);
```

Also update control handler init to 13 instead of 16.

## Alternative: Simpler Approach

Instead of custom INTEGER controls for parameters, we could:

1. **Use a single MENU control** for common autoshutter presets:
   - 0: Off
   - 1: Low sensitivity (temp=75, min=10s, max=600s)
   - 2: Medium sensitivity (temp=50, min=5s, max=300s)
   - 3: High sensitivity (temp=30, min=1s, max=120s)

2. **Or use IOCTL for advanced parameters** (like the original rs300_ioctl approach)

This would avoid the INTEGER control validation issues.

## Recommendation

After reboot:
1. Test that old driver still works
2. Try loading new driver with ONLY the boolean autoshutter control
3. If that works, add integer controls one at a time
4. If it still crashes, use the simpler MENU-based approach instead

## Files to Check After Reboot

```bash
# Check system is stable
uptime
journalctl --since "5 minutes ago" | tail -50

# Check old driver loads
sudo modprobe rs300
dmesg | grep rs300 | tail -20
lsmod | grep rs300
```
