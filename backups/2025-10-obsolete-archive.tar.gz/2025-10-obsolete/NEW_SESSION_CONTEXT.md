# ⚠️ OBSOLETE - Context for New Claude Code Session - RS300 Driver Consolidation

**Date Created**: 2024-10-24
**Date Obsoleted**: 2025-10-24
**Status**: ❌ **OBSOLETE - CONSOLIDATION ABANDONED**

This document was created for planning code consolidation which was subsequently ABANDONED.
See: `.claude/lessons-learned/002-consolidation-kernel-crash.md` for why.

**Preserved for historical reference only.**

---

# Original Context (For Historical Reference)

**Project**: RS300 Thermal Camera V4L2 Driver for Raspberry Pi 5
**Task**: Complete remaining code consolidation phases (ABANDONED)
**Working Directory**: `/home/cody/rs300-v4l2-driver`
**Original Date**: 2024-10-24

---

## Quick Context Summary

You are continuing a code consolidation project for a Linux kernel V4L2 driver. Phases 1.1 and 2 are **COMPLETE and TESTED** ✅. Your task is to complete the remaining phases (1.2, 3.1, 3.2, 4) following the detailed plan in `CONSOLIDATION_PLAN_REMAINING.md`.

---

## Project Overview

**What**: RS300 thermal camera (640×512@60fps) V4L2 driver
**Platform**: Raspberry Pi 5 (BCM2712, MIPI CSI-2 + I2C)
**Driver File**: `rs300.c` (currently 2,783 lines, OLD version checked out)
**Language**: C (Linux kernel module)
**Build System**: DKMS via `./setup.sh`

**Key Documentation**:
- `CLAUDE.md` - Project navigation and guidelines
- `DRIVER_ANALYSIS.md` - Complete driver architecture
- `SECURITY_AUDIT.md` - Security vulnerabilities (all CRITICAL/HIGH fixed)
- `CONSOLIDATION_PLAN_REMAINING.md` - **YOUR DETAILED WORK PLAN**

---

## Current Code State (CRITICAL)

**Active Code**: Consolidated version is in `git stash@{0}`
**Working Directory**: OLD version (pre-consolidation) currently checked out
**Git Branch**: `pi5-testing`
**Last Commit**: `faa1141 docs: Optimize I2C lookups and document camera warm-up timing`

**FIRST ACTION REQUIRED**: Restore consolidated code from stash
```bash
git stash pop
```

This will restore the code with Phases 1.1 & 2 already implemented.

---

## What's Been Completed ✅

### Phase 1.1: Enhanced `rs300_send_command()` Helper
**Status**: COMPLETE and TESTED

**Changes**:
- Added optional READ operation support (2 new parameters: `result_buffer`, `result_len`)
- Enhanced helper can now handle both write-only and GET commands
- All 9 existing callers updated with `, NULL, 0` for backward compatibility
- Result validation added (max 18 bytes)
- Result read logic implemented (reads from 0x1d00 after command success)

**Location**: Lines ~281-410 (after restoration from stash)

**Test Results**: ✅ All tests passed
- Helper executes write-only commands correctly
- Helper reads results correctly for GET operations
- No memory errors, no crashes

### Phase 2: Migrated 3 Old-Pattern Functions
**Status**: COMPLETE and TESTED

**Functions Consolidated**:

| Function | Before | After | Reduction | Status |
|----------|--------|-------|-----------|--------|
| `rs300_get_brightness()` | 130 lines | 24 lines | -106 lines (81%) | ✅ TESTED |
| `rs300_get_colormap()` | 88 lines | 21 lines | -67 lines (76%) | ✅ TESTED |
| `rs300_set_yuv_format()` | 70 lines | 17 lines | -53 lines (76%) | ✅ TESTED |

**Code Reduction**: 288 lines → 62 lines (**-226 lines, 78% reduction**)

**Test Results**: ✅ All tests passed
```bash
# Test script: ./test_consolidated_code.sh
✓ FFC Trigger - write-only command path works
✓ Colormap GET/SET - consolidated rs300_get_colormap() verified (0→3→0)
✓ Brightness GET/SET - consolidated rs300_get_brightness() verified (50→70→50)
✓ No kernel crashes, no errors
```

**IMPORTANT**: Driver is currently loaded and running with consolidated code. It's stable and working correctly.

---

## What Needs to Be Done (Your Tasks)

Read the complete implementation plan in: **`CONSOLIDATION_PLAN_REMAINING.md`**

### Phase 1.2: Extract `rs300_stop_streaming()` Helper
**Estimated Time**: 20 minutes
**Objective**: Create reusable helper for stopping streaming
**Why**: Needed for Phase 3.1 (fixing rs300_remove)

**Steps**:
1. Locate stop logic in `rs300_set_stream()` enable==0 branch
2. Extract ~20-30 lines into new function
3. Update caller to use new function
4. Compile and verify

**Deliverable**: New function `rs300_stop_streaming(struct rs300 *rs300)`

### Phase 3.1: Fix `rs300_remove()` - MEDIUM-001
**Estimated Time**: 25 minutes
**Objective**: Prevent resource leaks during module removal
**Security Issue**: MEDIUM-001 from SECURITY_AUDIT.md

**Current Problem**:
- Camera stays powered after rmmod (resource leak)
- Streaming not stopped (race condition risk)
- No mutex protection (concurrent access possible)

**Steps**:
1. Rewrite `rs300_remove()` with proper cleanup sequence
2. Add mutex protection
3. Check and stop streaming if active
4. Add power-off call
5. Test with rmmod (idle and during streaming)

**Deliverable**: Enhanced `rs300_remove()` function

### Phase 3.2: Reduce Kernel Log Flooding - MEDIUM-002
**Estimated Time**: 30 minutes
**Objective**: Convert verbose logging to dev_dbg

**Current Problem**:
- Each camera operation generates 20-30 log messages
- dmesg buffer fills quickly under load
- Makes debugging difficult

**Target**: >80% reduction in log volume

**Steps**:
1. Identify verbose logs in retry loops
2. Convert dev_info → dev_dbg for non-critical messages
3. Keep dev_err for actual errors
4. Keep dev_info for major milestones
5. Test log volume before/after

**Deliverable**: Reduced logging, errors still visible

### Phase 4: Documentation & Testing
**Estimated Time**: 60 minutes (40 doc + 20 test)
**Objective**: Update documentation and validate no regressions

**Steps**:
1. Generate new line number map for all functions
2. Update DRIVER_ANALYSIS.md line references
3. Update CLAUDE.md code location map
4. Update SECURITY_AUDIT.md line references
5. Run comprehensive test suite (7 test suites)
6. Measure and document log volume reduction

**Deliverable**: Updated docs, all tests passing

---

## Testing Requirements

**After Each Phase**:
```bash
# Always compile test
make clean && make 2>&1 | grep -E "error|warning"

# Load test (after rebuild)
sudo rmmod rs300 2>/dev/null
sudo modprobe rs300
dmesg | tail -20 | grep rs300
```

**After Phase 1.2**:
- Verify streaming still stops correctly
- Test set_stream(enable=0)

**After Phase 3.1**:
- Test rmmod while idle
- **CRITICAL**: Test rmmod while streaming
- Test 10 load/unload cycles

**After Phase 3.2**:
- Measure log volume: `dmesg | wc -l` after brightness change
- Verify errors still visible
- Test dynamic debug enables verbose logs

**Final Testing (Phase 4)**:
- Run `./test_controls.sh` (all 11 controls)
- Run `./test_consolidated_code.sh` (FFC, colormap, brightness)
- Stress test: 20 GET/SET iterations
- Stress test: 10 stream cycles
- Stress test: 10 load/unload cycles

**Success Criteria**: All tests pass, no kernel crashes, log volume reduced >80%

---

## Important Constraints

### Safety Rules
1. **NEVER use `insmod`** - Always use `sudo modprobe rs300` (uses DKMS)
2. **Test incrementally** - Compile and test after each phase
3. **Check for crashes** - Always run `dmesg | grep -E "Oops|BUG|segfault"` after testing
4. **Rollback on failure** - If kernel crashes, immediately `git checkout -- rs300.c`

### Code Style
- Match existing indentation (tabs, 8-space tab width)
- Preserve error handling patterns
- Follow kernel coding style
- Add comments for complex logic
- Use `dev_dbg` for verbose logs, `dev_err` for errors, `dev_info` for milestones

### Git Workflow
- Work on `pi5-testing` branch
- Do NOT commit until all phases complete and tested
- After completion: create descriptive commit message documenting changes

---

## Files You'll Modify

**Primary**:
- `rs300.c` - All code changes (Phases 1.2, 3.1, 3.2)

**Documentation** (Phase 4):
- `DRIVER_ANALYSIS.md` - Update line numbers in function table
- `CLAUDE.md` - Update code location map
- `SECURITY_AUDIT.md` - Update line references

**Read-Only References** (do not modify):
- `CONSOLIDATION_PLAN_REMAINING.md` - Your detailed work plan
- `I2C_PROTOCOL.md` - I2C command reference if needed
- `DEV_QUICK_REFERENCE.md` - Quick command reference

---

## Rollback Plan

**If compilation fails**:
```bash
git checkout -- rs300.c
make clean && make
```

**If kernel crashes**:
```bash
dmesg | tail -50 > /tmp/crash_log.txt
git checkout -- rs300.c
sudo modprobe rs300  # Reload old version
# Analyze /tmp/crash_log.txt
```

**If tests fail but no crash**:
- Document which test failed
- Review change that caused failure
- Fix incrementally
- Do not proceed to next phase until current phase passes

---

## Expected Outcomes

### Code Metrics
- **Starting size**: 2,783 lines (OLD version)
- **After stash restore**: 2,581 lines (Phase 1.1 & 2 complete)
- **After Phase 1.2**: ~2,575 lines (minimal change, refactor)
- **After Phase 3.1**: ~2,590 lines (+15 lines for enhanced rs300_remove)
- **After Phase 3.2**: 2,590 lines (no line count change, logging only)
- **Final**: ~2,590 lines (**-193 lines total, 7% reduction**)

### Quality Improvements
- ✅ Eliminated 226 lines of duplicate code
- ✅ Standardized command execution pattern
- ✅ Fixed resource leak (MEDIUM-001)
- ✅ Reduced log flooding (MEDIUM-002)
- ✅ Easier to add new camera commands (5-10 lines vs 70-130 lines)

### Performance
- Log volume: 80-90% reduction
- No performance degradation
- Faster development (new commands much easier)

---

## Key Functions Reference

**After stash restore, these functions exist**:

| Function | Approximate Line | Purpose |
|----------|------------------|---------|
| `rs300_send_command()` | ~281 | Enhanced helper with READ support |
| `rs300_get_brightness()` | ~731 | Consolidated (24 lines) |
| `rs300_get_colormap()` | ~990 | Consolidated (21 lines) |
| `rs300_set_yuv_format()` | ~861 | Consolidated (17 lines) |
| `rs300_set_stream()` | ~1754 | Contains stop logic to extract |
| `rs300_remove()` | ~2733 | Needs enhancement (Phase 3.1) |

**You will create**:
- `rs300_stop_streaming()` - Phase 1.2 (new function)

**Use these for reference**:
```bash
# Find any function quickly
grep -n "^static.*function_name" rs300.c
```

---

## First Steps When Starting

1. **Restore consolidated code**:
   ```bash
   cd ~/rs300-v4l2-driver
   git stash pop
   ```

2. **Verify code state**:
   ```bash
   wc -l rs300.c  # Should show ~2581 lines
   git status     # Should show modified rs300.c
   ```

3. **Read the detailed plan**:
   ```bash
   cat CONSOLIDATION_PLAN_REMAINING.md
   ```

4. **Start with Phase 1.2**: Extract `rs300_stop_streaming()` helper

5. **Use TodoWrite tool** to track progress through phases

---

## Questions to Ask Me

If you need clarification on:
- Specific code patterns or existing functions
- Testing procedures or expected results
- Whether a particular change is safe
- Git workflow or commit strategy

Just ask! I can provide additional context, code examples, or guidance.

---

## Success Definition

**All phases complete when**:
- [ ] All code compiles without errors
- [ ] No kernel crashes during testing
- [ ] All test suites pass (7 test suites in Phase 4)
- [ ] Module loads/unloads cleanly
- [ ] `rs300_remove()` works during active streaming
- [ ] Log volume reduced by >80%
- [ ] Documentation updated with correct line numbers
- [ ] Ready for git commit

**Timeline**: ~2.5 hours if everything goes smoothly

---

**Ready to begin!** Start by restoring the consolidated code from git stash, then proceed with Phase 1.2 following the detailed plan in `CONSOLIDATION_PLAN_REMAINING.md`.
