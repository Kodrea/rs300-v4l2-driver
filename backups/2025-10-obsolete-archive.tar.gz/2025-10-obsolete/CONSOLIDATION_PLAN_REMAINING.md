# ⚠️ ABANDONED - RS300 Driver Code Consolidation Plan

**Date Created**: 2024-10-24
**Date Abandoned**: 2025-10-24
**Final Status**: ❌ **ABANDONED - CAUSED KERNEL CRASHES**

---

## ⚠️ DO NOT IMPLEMENT THIS PLAN

This consolidation plan was **ABANDONED** after Phase 1.1 testing caused mysterious kernel crashes:
- **Bug**: kernel BUG at `drivers/media/mc/mc-entity.c:146` during probe
- **Mystery**: Modified function wasn't even called during probe
- **Root Cause**: Likely ARM64 ABI issue with function parameter changes
- **Decision**: Leave code as-is, accept duplication

**See**: `.claude/lessons-learned/002-consolidation-kernel-crash.md` for complete analysis.

---

# Original Plan (For Historical Reference)

**Original Date**: 2024-10-24
**Original Status**: Phases 1.1 & 2 COMPLETE and TESTED ✅ | Phases 1.2, 3.1-3.2, 4 PENDING

---

## Current State Summary

### ✅ Completed Work (Tested and Verified)

**Phase 1.1**: Enhanced `rs300_send_command()` Helper
- Added optional READ operation support via `result_buffer` and `result_len` parameters
- All 9 existing write-only callers updated with `, NULL, 0` parameters
- **Lines modified**: ~30 lines added to helper function

**Phase 2**: Migrated 3 Old-Pattern Functions
| Function | Before | After | Reduction |
|----------|--------|-------|-----------|
| `rs300_get_brightness()` | 130 lines | 24 lines | -106 lines (81%) |
| `rs300_get_colormap()` | 88 lines | 21 lines | -67 lines (76%) |
| `rs300_set_yuv_format()` | 70 lines | 17 lines | -53 lines (76%) |
| **Total** | **288 lines** | **62 lines** | **-226 lines (78%)** |

**Test Results**: All tests passed ✅
- Driver loads without crashes
- FFC trigger works (write-only path)
- Colormap GET/SET verified (consolidated code path)
- Brightness GET/SET verified (consolidated code path)
- No kernel errors or warnings

**Code Location**: Changes currently in `git stash@{0}`

### 📋 Remaining Work

**Phase 1.2**: Extract `rs300_stop_streaming()` Helper (Est: 20 min)
**Phase 3.1**: Fix `rs300_remove()` - MEDIUM-001 (Est: 25 min)
**Phase 3.2**: Reduce Kernel Log Flooding - MEDIUM-002 (Est: 30 min)
**Phase 4**: Documentation Update & Testing (Est: 80 min)

**Total Remaining**: ~2.5 hours

---

## Phase 1.2: Extract `rs300_stop_streaming()` Helper

### Objective
Create reusable helper function for stopping streaming, callable from both:
- `rs300_set_stream(enable=0)`
- `rs300_remove()` (Phase 3.1)

### Current Situation

**Location**: `rs300_set_stream()` function, enable==0 branch
**Approximate line range**: Search for `rs300_set_stream`, find the `else` branch

**Current code structure**:
```c
static int rs300_set_stream(struct v4l2_subdev *sd, int enable) {
    if (enable) {
        // Start streaming logic...
    } else {
        // === THIS BLOCK NEEDS EXTRACTION ===
        // ~20-30 lines of:
        // - Build stop_regs command
        // - Send to camera via write_regs
        // - Poll status register
        // - Clear streaming flag
        // ===================================
    }
}
```

### Implementation Steps

#### Step 1: Locate Stop Streaming Code
```bash
# Find the function
grep -n "^static int rs300_set_stream" rs300.c

# Read the complete function to understand structure
# Look for the 'else' branch that handles enable==0
```

**Expected pattern to extract**:
1. Local variable declarations (stop_regs buffer)
2. Command buffer construction
3. write_regs() call
4. Status polling with retry loop
5. `rs300->streaming = false;`

#### Step 2: Design New Function

**Signature**:
```c
/**
 * rs300_stop_streaming - Stop camera streaming
 * @rs300: RS300 device structure
 *
 * Sends stop command to camera hardware and clears streaming flag.
 * Must be called with rs300->mutex held.
 *
 * Returns: 0 on success, negative error code on failure
 */
static int rs300_stop_streaming(struct rs300 *rs300);
```

**Placement**: Insert AFTER `rs300_set_fps()`, BEFORE `rs300_set_stream()`

**Implementation template**:
```c
static int rs300_stop_streaming(struct rs300 *rs300)
{
    struct i2c_client *client = v4l2_get_subdevdata(&rs300->sd);
    u8 stop_regs[28];  // Actual size from existing code
    int ret;

    dev_info(&client->dev, "Stopping streaming");

    // === COPY STOP COMMAND CONSTRUCTION FROM set_stream ===
    // Build stop_regs array
    // Calculate CRC
    // ======================================================

    // Send stop command
    ret = write_regs(client, I2C_VD_BUFFER_RW, stop_regs, sizeof(stop_regs));
    if (ret) {
        dev_err(&client->dev, "Failed to send stop command: %d", ret);
        return ret;
    }

    // === COPY STATUS POLLING LOGIC FROM set_stream ===
    // Poll until camera acknowledges stop
    // ==================================================

    // Clear streaming flag only after successful stop
    rs300->streaming = false;
    dev_info(&client->dev, "Streaming stopped");

    return 0;
}
```

#### Step 3: Update `rs300_set_stream()` Caller

**Replace**:
```c
} else {
    // 20-30 lines of stop logic
    rs300->streaming = false;
}
```

**With**:
```c
} else {
    ret = rs300_stop_streaming(rs300);
    if (ret)
        dev_err(&client->dev, "Failed to stop streaming: %d\n", ret);
    return ret;
}
```

#### Step 4: Verification

**Compile test**:
```bash
make clean && make 2>&1 | grep -E "error|warning"
```

**Expected**: No new errors/warnings

**Functional test** (manual):
```bash
# Test that streaming still stops correctly
v4l2-ctl -d /dev/video0 --set-fmt-video=width=640,height=512 --stream-mmap --stream-count=10
# Should complete without errors
dmesg | tail -10 | grep "Stopping streaming"
```

### Challenges & Solutions

| Challenge | Solution |
|-----------|----------|
| **C1**: Stop code uses local vars from set_stream | Recreate variables in new function |
| **C2**: Error handling differs between contexts | Preserve existing behavior, log errors |
| **C3**: Streaming flag timing | Only clear flag AFTER successful hardware stop |

### Completion Criteria
- [ ] New function compiles without errors
- [ ] rs300_set_stream(enable=0) calls new function
- [ ] Streaming flag cleared only on success
- [ ] Existing stream stop tests still pass

---

## Phase 3.1: Fix `rs300_remove()` - MEDIUM-001 Resource Cleanup

### Objective
Prevent resource leaks and crashes during module removal by adding:
- Streaming state check
- Camera power-off
- Mutex protection

### Current Situation

**Location**: `rs300_remove()` function (near end of file)
**Current implementation** (incomplete):
```c
static void rs300_remove(struct i2c_client *client)
{
    struct v4l2_subdev *sd = i2c_get_clientdata(client);
    struct rs300 *rs300 = to_rs300(sd);

    v4l2_async_unregister_subdev(sd);
    media_entity_cleanup(&sd->entity);
    rs300_free_controls(rs300);
    // MISSING: Stop streaming check
    // MISSING: Power-off call
    // MISSING: Mutex protection
}
```

**Security Issue**: MEDIUM-001 from SECURITY_AUDIT.md
- Camera stays powered after rmmod (resource leak)
- Streaming not stopped (potential race condition)
- No mutex protection (concurrent I2C access possible)

### Implementation Steps

#### Step 1: Analyze Dependencies

**Check power-off function**:
```bash
grep -n "^static int rs300_power_off" rs300.c -A 5
```

**Expected signature**: `static int rs300_power_off(struct device *dev)`

**Check if called anywhere**:
```bash
grep -n "rs300_power_off" rs300.c
```

#### Step 2: Design Cleanup Sequence

**Critical order** (for safety):
```
1. Lock mutex            → Prevent concurrent operations
2. Check streaming       → Detect active streams
3. Stop streaming        → Call rs300_stop_streaming() if needed
4. Unlock mutex          → Allow final I2C to complete
5. Unregister V4L2       → Prevent new userspace access
6. Cleanup media entity  → Release media graph
7. Free controls         → Release V4L2 control structures
8. Power off camera      → GPIO/regulator cleanup
```

**Why this order**:
- Mutex protection prevents race with ongoing operations
- Stop streaming while holding mutex ensures atomic state change
- Release mutex before V4L2 unregister (subsystem may need it)
- Power-off last ensures all I2C operations complete first

#### Step 3: Implementation

**Complete rewrite**:
```c
static void rs300_remove(struct i2c_client *client)
{
    struct v4l2_subdev *sd = i2c_get_clientdata(client);
    struct rs300 *rs300 = to_rs300(sd);
    int ret;

    dev_info(&client->dev, "Removing RS300 driver");

    /* Stop streaming if active (with mutex protection) */
    mutex_lock(&rs300->mutex);
    if (rs300->streaming) {
        dev_info(&client->dev, "Stopping active streaming before removal");
        ret = rs300_stop_streaming(rs300);
        if (ret)
            dev_warn(&client->dev,
                     "Failed to stop streaming during removal: %d", ret);
    }
    mutex_unlock(&rs300->mutex);

    /* Unregister from V4L2 subsystem */
    v4l2_async_unregister_subdev(sd);
    media_entity_cleanup(&sd->entity);
    rs300_free_controls(rs300);

    /* Power off camera hardware */
    ret = rs300_power_off(&client->dev);
    if (ret)
        dev_warn(&client->dev, "Failed to power off camera: %d", ret);

    dev_info(&client->dev, "RS300 driver removed successfully");
}
```

#### Step 4: Verification

**Compile test**:
```bash
make clean && make 2>&1 | tail -20
```

**Expected**: Clean build, no errors

**Functional tests**:

**Test 1: Remove while idle**
```bash
sudo modprobe rs300
lsmod | grep rs300
sudo rmmod rs300
dmesg | tail -10
```
**Expected**: "Removing RS300 driver", "removed successfully", no errors

**Test 2: Remove while streaming** (CRITICAL)
```bash
sudo modprobe rs300
# Start background streaming
v4l2-ctl -d /dev/video0 --set-fmt-video=width=640,height=512 \
         --stream-mmap --stream-count=1000 &
STREAM_PID=$!
sleep 2  # Let streaming start
sudo rmmod rs300
dmesg | tail -20
```
**Expected**:
- "Stopping active streaming before removal"
- "Streaming stopped"
- "removed successfully"
- No crashes, no "module in use" error

**Test 3: Multiple load/unload cycles**
```bash
for i in {1..10}; do
    echo "=== Cycle $i ==="
    sudo modprobe rs300
    sleep 2
    sudo rmmod rs300
    sleep 1
done
```
**Expected**: All cycles succeed, no errors

### Challenges & Solutions

| Challenge | Solution |
|-----------|----------|
| **C1**: rs300_power_off takes `struct device *`, not `struct rs300 *` | Use `&client->dev` |
| **C2**: Power-off might fail if camera already off | Log warning but continue cleanup |
| **C3**: V4L2 subsystem may hold references | Stop streaming BEFORE unregistering |
| **C4**: rmmod may fail with "module in use" | Ensure all /dev/video* handles closed |

### Completion Criteria
- [ ] Driver compiles without errors
- [ ] Remove while idle works cleanly
- [ ] Remove while streaming stops stream first
- [ ] No kernel crashes during removal
- [ ] No resource leak warnings in dmesg

---

## Phase 3.2: Reduce Kernel Log Flooding - MEDIUM-002

### Objective
Convert verbose logging to `dev_dbg`, reduce kernel log volume by >80% while preserving error visibility.

### Current Situation

**Problem**: Each camera operation generates 20-30 log messages
- Stream start: ~30 messages (retry loops, status checks)
- Control operations: ~10 messages per operation
- Under load: dmesg buffer fills in <1 minute

**Example excessive logging**:
```
[  96.848649] rs300 10-003c: Read back registers: 01 30 c1 ...
[  96.848650] rs300 10-003c: Setting frame format: code=0x2011...
[  96.849161] rs300 10-003c: Attempt 1/3 - Status check 0: 0x01
[  96.950776] rs300 10-003c: Attempt 1/3 - Status check 1: 0x00
[  96.950778] rs300 10-003c: Busy bit cleared
```

### Implementation Steps

#### Step 1: Audit Current Logging

**Primary target**: Stream start retry loop in `rs300_set_stream()`

**Find location**:
```bash
grep -n "Attempt.*Status check" rs300.c
```

**Secondary targets**:
```bash
# Find all dev_info in retry loops
grep -n "dev_info.*retry\|dev_info.*attempt" rs300.c -i
```

#### Step 2: Classification Matrix

**Convert dev_info → dev_dbg**:
- Status polling messages ("Attempt N/3...", "Status check", "Busy bit")
- Register dumps ("Read back registers")
- Intermediate state ("Setting frame format")
- Retry attempts ("Retrying...")

**KEEP as dev_info**:
- Success milestones ("Stream started successfully")
- State changes ("Stopping stream")
- Device lifecycle ("Removing RS300 driver")

**KEEP as dev_err**:
- All failures ("Stream failed", "timeout", "Command failed")
- Error code interpretation
- Hardware errors

#### Step 3: Systematic Conversion

**Target locations** (search for these patterns):

**Location 1: rs300_set_stream retry loop**
```bash
grep -n "Attempt.*Status check" rs300.c
```

**Before**:
```c
dev_info(&client->dev, "Attempt %d/3 - Status check %d: 0x%02x",
         attempt, check, status);
dev_info(&client->dev, "Busy bit cleared");
```

**After**:
```c
dev_dbg(&client->dev, "Attempt %d/3 - Status check %d: 0x%02x",
        attempt, check, status);
dev_dbg(&client->dev, "Busy bit cleared");
```

**Location 2: Register read verification**
```bash
grep -n "Read back registers" rs300.c
```

**Before**:
```c
dev_info(&client->dev, "Read back registers: %*ph", ...);
```

**After**:
```c
dev_dbg(&client->dev, "Read back registers: %*ph", ...);
```

**Location 3: Frame format messages**
```bash
grep -n "Setting frame format" rs300.c
```

**Before**:
```c
dev_info(&client->dev, "Setting frame format: code=0x%x...", ...);
```

**After**:
```c
dev_dbg(&client->dev, "Setting frame format: code=0x%x...", ...);
```

#### Step 4: Verification Strategy

**After each change**:
```bash
# Verify change applied correctly
grep -n "dev_dbg.*Attempt" rs300.c

# Verify no critical errors converted
grep -n "dev_err" rs300.c | grep -E "failed|timeout|error"
```

**Compilation test**:
```bash
make clean && make 2>&1 | tail -10
```

#### Step 5: Functional Testing

**Test 1: Verify reduced log volume**
```bash
sudo dmesg -C
v4l2-ctl -d /dev/v4l-subdev2 -c brightness=75
dmesg | wc -l
```
**Expected**: < 5 lines (vs previous ~30 lines)

**Test 2: Verify errors still visible**
```bash
# Cause an error (disconnect camera or use invalid value)
v4l2-ctl -d /dev/v4l-subdev2 -c brightness=9999
dmesg | tail -10
```
**Expected**: Error messages still appear

**Test 3: Verify debug logs available when needed**
```bash
# Enable dynamic debug (if kernel supports it)
echo "module rs300 +p" | sudo tee /sys/kernel/debug/dynamic_debug/control
v4l2-ctl -d /dev/v4l-subdev2 -c brightness=75
dmesg | tail -30
```
**Expected**: Verbose debug logs now visible

**Test 4: Stream start log volume**
```bash
sudo dmesg -C
# Start and stop streaming
v4l2-ctl -d /dev/video0 --set-fmt-video=width=640,height=512 \
         --stream-mmap --stream-count=10
dmesg | wc -l
```
**Expected**: < 10 lines (vs previous ~50+ lines)

### Changes Summary Table

| Message Type | Current Level | New Level | Count |
|--------------|---------------|-----------|-------|
| Status polling (busy bit, etc) | `dev_info` | `dev_dbg` | ~15 |
| Register dumps | `dev_info` | `dev_dbg` | ~5 |
| Intermediate states | `dev_info` | `dev_dbg` | ~8 |
| Success milestones | `dev_info` | **KEEP** | ~3 |
| Errors/failures | `dev_err` | **KEEP** | ~10 |

**Estimated reduction**: 28 messages → 3-5 messages per operation (80-85% reduction)

### Challenges & Solutions

| Challenge | Solution |
|-----------|----------|
| **C1**: Multi-line log statements hard to match | Use grep with -A/-B to capture exact text |
| **C2**: May accidentally convert critical errors | Maintain whitelist of "must keep" patterns |
| **C3**: Dynamic debug may not be available | Document alternative (module debug=2 parameter) |

### Completion Criteria
- [ ] Log volume reduced by >80%
- [ ] All errors still visible in dmesg
- [ ] Success milestones still visible
- [ ] Debug logs available via dynamic_debug
- [ ] No compilation errors

---

## Phase 4: Documentation Update & Comprehensive Testing

### Objective
Update all documentation with new line numbers and validate no regressions in functionality.

### Part A: Documentation Updates

#### Files to Update

**Priority 1** (Must update - contains line references):

**1. DRIVER_ANALYSIS.md**
- Contains ~20 function references with line numbers
- Example: "rs300_send_command (lines 278-393)"
- Strategy: Generate line number map, update systematically

**2. CLAUDE.md - Code Location Map**
- Table with ~18 entries
- Each entry has line number range
- Update all entries in "Critical Functions" table

**3. SECURITY_AUDIT.md**
- References lines where security fixes were applied
- Update to reflect current line numbers
- Note: Fixes already applied, just update references

**Priority 2** (Check for line references):
- DEV_QUICK_REFERENCE.md
- README.md
- TROUBLESHOOTING.md

#### Update Strategy

**Step 1: Generate Line Number Map**
```bash
# Create automated line number extraction
for func in rs300_send_command rs300_get_brightness rs300_get_colormap \
            rs300_set_stream rs300_set_fps rs300_probe rs300_remove \
            rs300_stop_streaming rs300_init_controls rs300_set_ctrl; do
    line=$(grep -n "^static.*$func" rs300.c | cut -d: -f1)
    echo "$func: $line"
done > /tmp/line_numbers.txt
```

**Step 2: Update DRIVER_ANALYSIS.md**

**Section to update**: "Critical Functions (with line numbers in rs300.c)"

**Process**:
1. Read /tmp/line_numbers.txt
2. Find each function in DRIVER_ANALYSIS.md
3. Update line number
4. Verify update with grep

**Example update**:
```markdown
Before: | rs300_send_command | 278-393 | ...
After:  | rs300_send_command | 281-410 | ...
```

**Step 3: Update CLAUDE.md**

**Section to update**: "Code Location Map" table

**Process**: Same as DRIVER_ANALYSIS.md

**Step 4: Update SECURITY_AUDIT.md**

**Focus**: Update line references in "Fixed Issues" section
**Note**: Add comment that consolidation shifted lines, fixes still in place

### Part B: Comprehensive Testing

#### Test Suite 1: Build & Load
```bash
make clean && make
sudo rmmod rs300
sudo modprobe rs300
lsmod | grep rs300
dmesg | tail -30 | grep rs300
```
**Expected**: Clean build, clean load, no errors

#### Test Suite 2: All V4L2 Controls (Existing Script)
```bash
./test_controls.sh
```
**Expected**: All 11 controls respond correctly
**Time**: ~5 minutes

#### Test Suite 3: Consolidated Functions Stress Test
```bash
# Test GET operations (20 iterations)
for i in {1..20}; do
    echo "=== GET iteration $i ==="
    BRIGHT=$(v4l2-ctl -d /dev/v4l-subdev2 -C brightness | grep -oP '\d+')
    CMAP=$(v4l2-ctl -d /dev/v4l-subdev2 -C colormap | grep -oP '\d+')
    echo "Brightness: $BRIGHT, Colormap: $CMAP"
    [ -z "$BRIGHT" ] && echo "ERROR: GET brightness failed" && exit 1
    [ -z "$CMAP" ] && echo "ERROR: GET colormap failed" && exit 1
done

# Test SET operations (20 iterations with varying values)
for i in {1..20}; do
    echo "=== SET iteration $i ==="
    NEW_BRIGHT=$((50 + i))
    NEW_CMAP=$((i % 12))
    v4l2-ctl -d /dev/v4l-subdev2 -c brightness=$NEW_BRIGHT,colormap=$NEW_CMAP
    sleep 0.2
done

echo "✓ Stress test completed successfully"
```
**Expected**: All iterations succeed, no timeouts
**Time**: ~2 minutes

#### Test Suite 4: Streaming Stress Test
```bash
# 10 stream cycles
for i in {1..10}; do
    echo "=== Stream cycle $i ==="
    v4l2-ctl -d /dev/video0 --set-fmt-video=width=640,height=512 \
             --stream-mmap --stream-count=100
    if [ $? -ne 0 ]; then
        echo "ERROR: Stream cycle $i failed"
        exit 1
    fi
    sleep 1
done

echo "✓ Streaming stress test completed"
```
**Expected**: No crashes, no timeouts, consistent performance
**Time**: ~5 minutes

#### Test Suite 5: Module Load/Unload Cycles
```bash
# 10 load/unload cycles
for i in {1..10}; do
    echo "=== Cycle $i ==="
    sudo modprobe rs300
    sleep 2
    lsmod | grep rs300 || { echo "ERROR: Module not loaded"; exit 1; }
    sudo rmmod rs300 || { echo "ERROR: Module removal failed"; exit 1; }
    sleep 1
done

echo "✓ Load/unload cycles completed"
```
**Expected**: All cycles succeed, no "module in use", no crashes
**Time**: ~3 minutes

#### Test Suite 6: Remove During Active Streaming (Phase 3.1 validation)
```bash
sudo modprobe rs300
# Start long-running stream in background
v4l2-ctl -d /dev/video0 --set-fmt-video=width=640,height=512 \
         --stream-mmap --stream-count=5000 &
STREAM_PID=$!
sleep 2
echo "Removing module while streaming..."
sudo rmmod rs300
dmesg | tail -30 | grep -E "Stopping active streaming|removed successfully"
```
**Expected**: Clean shutdown, streaming stopped before removal
**Time**: 1 minute

#### Test Suite 7: Log Volume Measurement
```bash
# Before Phase 3.2 (from baseline)
BEFORE=30  # Known baseline

# After Phase 3.2
sudo dmesg -C
v4l2-ctl -d /dev/v4l-subdev2 -c brightness=75
AFTER=$(dmesg | wc -l)

REDUCTION=$(( (BEFORE - AFTER) * 100 / BEFORE ))
echo "Log reduction: $REDUCTION% (from $BEFORE to $AFTER lines)"

if [ $REDUCTION -lt 80 ]; then
    echo "WARNING: Log reduction below target (80%)"
fi
```
**Expected**: >80% reduction
**Time**: 1 minute

### Testing Summary

| Test Suite | Duration | Pass Criteria |
|------------|----------|---------------|
| Build & Load | 2 min | Clean build, loads without error |
| All Controls | 5 min | All 11 controls functional |
| GET/SET Stress | 2 min | 20 iterations, no failures |
| Streaming Stress | 5 min | 10 cycles, no crashes |
| Load/Unload | 3 min | 10 cycles, clean removal |
| Remove While Streaming | 1 min | Streaming stopped first |
| Log Volume | 1 min | >80% reduction |
| **Total** | **~20 min** | All tests pass |

### Completion Criteria

**Must achieve**:
- [ ] No compilation errors
- [ ] No kernel crashes in any test
- [ ] All existing tests pass
- [ ] Module removal works cleanly
- [ ] Log volume reduced >80%
- [ ] Documentation updated

**Should achieve**:
- [ ] All stress tests pass (100+ iterations)
- [ ] No regressions in any functionality
- [ ] Performance maintained or improved

**Nice to have**:
- [ ] Automated test script created
- [ ] Test results documented
- [ ] Ready for git commit

---

## Rollback Plan

### Immediate Rollback Triggers
1. Compilation fails with errors
2. Kernel crash (Oops/BUG) during testing
3. Module fails to load
4. Critical functionality broken (streaming, controls not working)
5. More than 2 test suites fail

### Rollback Procedure

**Step 1: Save failed changes for analysis**
```bash
cd ~/rs300-v4l2-driver
git diff HEAD > /tmp/failed_changes_$(date +%Y%m%d_%H%M%S).patch
```

**Step 2: Revert to last known good state**
```bash
git checkout -- rs300.c
git status  # Verify clean
```

**Step 3: Rebuild and verify**
```bash
make clean && make
sudo rmmod rs300 2>/dev/null
sudo modprobe rs300
```

**Step 4: Verify old code works**
```bash
./test_consolidated_code.sh
```
**Expected**: All tests pass (confirms rollback successful)

**Step 5: Analyze failure**
```bash
# Review what failed
cat /tmp/failed_changes_*.patch
dmesg | tail -50
# Identify specific change that caused failure
```

**Step 6: Incremental fix**
- Fix one issue at a time
- Test after each change
- Do not proceed until stable

### Partial Success Strategy

If some phases complete but others fail:
- **Keep working phases**: Cherry-pick successful changes
- **Isolate failures**: Debug failed phase separately
- **Document state**: Note what works, what doesn't

---

## Success Metrics

### Code Quality
- **Before consolidation**: 2,783 lines
- **After Phase 2**: 2,581 lines (-202 lines)
- **Expected after all phases**: ~2,500 lines (-283 lines, 10% reduction)

### Performance
- **Log volume**: 80-90% reduction
- **Function complexity**: Reduced from 130-line functions to 20-line functions
- **Maintainability**: New commands require 5-10 lines vs 70-130 lines

### Stability
- **Zero kernel crashes**
- **Zero resource leaks**
- **100% test pass rate**

---

## Timeline Estimate

| Phase | Task | Time | Cumulative |
|-------|------|------|------------|
| 1.2 | Extract stop_streaming helper | 20 min | 20 min |
| 3.1 | Fix rs300_remove | 25 min | 45 min |
| 3.2 | Reduce log flooding | 30 min | 75 min |
| 4.A | Update documentation | 40 min | 115 min |
| 4.B | Comprehensive testing | 20 min | 135 min |
| Buffer | Debugging/fixes | 15 min | 150 min |
| **Total** | | **2.5 hours** | |

---

## Post-Completion Actions

1. **Git commit** with detailed message documenting changes
2. **Update START_HERE.md** with completion status
3. **Create CONSOLIDATION_SUMMARY.md** with before/after metrics
4. **Optional**: Create pull request if contributing upstream

---

**END OF PLAN**
