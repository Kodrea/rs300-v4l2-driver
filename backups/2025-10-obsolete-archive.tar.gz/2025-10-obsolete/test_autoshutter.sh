#!/bin/bash
# Test autoshutter controls for RS300 thermal camera

DEVICE="/dev/v4l-subdev2"

echo "=========================================="
echo "RS300 Autoshutter Control Test"
echo "=========================================="
echo ""

echo "1. Checking available controls..."
v4l2-ctl -d $DEVICE --list-ctrls | grep -i "auto\|shutter"
echo ""

echo "2. Getting current autoshutter state..."
v4l2-ctl -d $DEVICE --get-ctrl=auto_shutter 2>/dev/null || echo "Control not found - driver may need reloading"
echo ""

echo "3. Testing autoshutter enable (turning ON)..."
v4l2-ctl -d $DEVICE -c auto_shutter=1
echo "Checking dmesg for confirmation:"
dmesg | tail -5 | grep -i autoshutter
echo ""

echo "4. Setting temperature threshold to 50 (1.56°C)..."
v4l2-ctl -d $DEVICE -c auto_shutter_temperature=50
echo "Checking dmesg:"
dmesg | tail -5 | grep -i "autoshutter\|param"
echo ""

echo "5. Setting minimum interval to 5 seconds..."
v4l2-ctl -d $DEVICE -c auto_shutter_min_interval=5
echo "Checking dmesg:"
dmesg | tail -5 | grep -i "autoshutter\|param"
echo ""

echo "6. Setting maximum interval to 300 seconds..."
v4l2-ctl -d $DEVICE -c auto_shutter_max_interval=300
echo "Checking dmesg:"
dmesg | tail -5 | grep -i "autoshutter\|param"
echo ""

echo "7. Getting current autoshutter state again..."
v4l2-ctl -d $DEVICE --get-ctrl=auto_shutter
echo ""

echo "8. Testing autoshutter disable (turning OFF)..."
v4l2-ctl -d $DEVICE -c auto_shutter=0
echo "Checking dmesg:"
dmesg | tail -5 | grep -i autoshutter
echo ""

echo "=========================================="
echo "Test complete!"
echo "=========================================="
echo ""
echo "All autoshutter controls:"
v4l2-ctl -d $DEVICE --list-ctrls | grep -E "auto_shutter|autoshutter"
