#!/bin/bash
# Working RS300 configuration - Generated Wed 22 Oct 07:03:05 EDT 2025
# This script reproduces a working media pipeline configuration

./configure_media.sh --format YUYV8_1X16 --pixelformat YUYV --width 640 --height 512 --non-interactive
