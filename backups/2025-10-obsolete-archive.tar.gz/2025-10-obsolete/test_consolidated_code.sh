#!/bin/bash
# ⚠️ OBSOLETE - DO NOT USE (2025-10-24)
# This script was created for testing code consolidation which was ABANDONED.
# See: .claude/lessons-learned/002-consolidation-kernel-crash.md
#
# Original purpose: Test consolidated rs300_send_command() implementation
# Tests: FFC trigger, colormap GET/SET, brightness GET/SET

DEVICE="/dev/v4l-subdev2"
LOG_FILE="/tmp/rs300_test_log.txt"

echo "========================================"
echo "RS300 Consolidated Code Test"
echo "========================================"
echo "Testing device: $DEVICE"
echo "Log file: $LOG_FILE"
echo ""

# Clear dmesg buffer
sudo dmesg -C

# Test 1: FFC Trigger (write-only command)
echo "TEST 1: FFC Trigger (shutter calibration - write-only path)"
echo "----------------------------------------"
echo "Triggering FFC..."
v4l2-ctl -d $DEVICE -c ffc_trigger=1
if [ $? -eq 0 ]; then
    echo "✓ FFC trigger command sent successfully"
else
    echo "✗ FFC trigger command FAILED"
fi
sleep 6  # FFC takes ~5 seconds
echo ""

# Test 2: Colormap GET/SET (READ path)
echo "TEST 2: Colormap GET/SET (tests READ path)"
echo "----------------------------------------"

# Get current colormap
echo "Reading current colormap..."
CURRENT_MAP=$(v4l2-ctl -d $DEVICE -C colormap 2>&1 | grep -oP 'colormap: \K\d+')
echo "Current colormap: $CURRENT_MAP"

# Set to different colormap (Ironbow = 3)
echo "Setting colormap to 3 (Ironbow)..."
v4l2-ctl -d $DEVICE -c colormap=3
sleep 1

# Verify by reading back
NEW_MAP=$(v4l2-ctl -d $DEVICE -C colormap 2>&1 | grep -oP 'colormap: \K\d+')
echo "New colormap after SET: $NEW_MAP"

if [ "$NEW_MAP" == "3" ]; then
    echo "✓ Colormap GET/SET verified correctly"
else
    echo "✗ Colormap verification FAILED (expected 3, got $NEW_MAP)"
fi
echo ""

# Test 3: Brightness GET/SET (READ path)
echo "TEST 3: Brightness GET/SET (tests READ path)"
echo "----------------------------------------"

# Get current brightness
echo "Reading current brightness..."
CURRENT_BRIGHT=$(v4l2-ctl -d $DEVICE -C brightness 2>&1 | grep -oP 'brightness: \K\d+')
echo "Current brightness: $CURRENT_BRIGHT"

# Set to different brightness (70)
echo "Setting brightness to 70..."
v4l2-ctl -d $DEVICE -c brightness=70
sleep 1

# Verify by reading back
NEW_BRIGHT=$(v4l2-ctl -d $DEVICE -C brightness 2>&1 | grep -oP 'brightness: \K\d+')
echo "New brightness after SET: $NEW_BRIGHT"

if [ "$NEW_BRIGHT" == "70" ]; then
    echo "✓ Brightness GET/SET verified correctly"
else
    echo "✗ Brightness verification FAILED (expected 70, got $NEW_BRIGHT)"
fi
echo ""

# Restore original values
echo "Restoring original values..."
v4l2-ctl -d $DEVICE -c colormap=$CURRENT_MAP
v4l2-ctl -d $DEVICE -c brightness=$CURRENT_BRIGHT
echo ""

# Capture dmesg logs
echo "========================================"
echo "Capturing kernel logs (dmesg)..."
echo "========================================"
sudo dmesg > $LOG_FILE

# Check for errors in logs
ERROR_COUNT=$(grep -i "error\|fail\|warning" $LOG_FILE | grep -c rs300)
if [ $ERROR_COUNT -eq 0 ]; then
    echo "✓ No errors found in kernel logs"
else
    echo "⚠ Found $ERROR_COUNT potential issues in logs"
    echo ""
    echo "Sample errors/warnings:"
    grep -i "error\|fail\|warning" $LOG_FILE | grep rs300 | head -5
fi

echo ""
echo "Full logs saved to: $LOG_FILE"
echo "========================================"
echo "Test Summary:"
echo "  - FFC Trigger: Write-only command path"
echo "  - Colormap: READ + write verification"
echo "  - Brightness: READ + write verification"
echo "========================================"
