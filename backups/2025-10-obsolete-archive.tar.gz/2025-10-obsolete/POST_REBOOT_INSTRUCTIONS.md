# ⚠️ OBSOLETE - Post-Reboot Test Instructions

**Date Created**: 2024-10-24
**Date Obsoleted**: 2025-10-24
**Status**: ❌ **OBSOLETE - CONSOLIDATION ABANDONED**

This document was created for testing consolidated code which was subsequently ABANDONED.
See: `.claude/lessons-learned/002-consolidation-kernel-crash.md` for why.

**Preserved for historical reference only.**

---

# Original Instructions (For Historical Reference)

**Original Date**: 2024-10-24
**Original Code**: Consolidated rs300_send_command() with READ support (ABANDONED)

## What Was Supposed To Be Installed (Never Successfully Tested)
- ❌ NEW driver code (202 lines smaller, GET/SET functions consolidated) - CAUSED CRASHES
- ✅ Automatic boot configuration (systemd + udev) - This was installed but unrelated

---

## QUICK START (Copy-Paste After Reboot)

```bash
# 1. Check driver loaded
lsmod | grep rs300

# 2. Check for crashes
dmesg | grep -i "rs300.*oops\|rs300.*bug\|segmentation" | tail -20

# 3. Run test script
cd ~/rs300-v4l2-driver
./test_consolidated_code.sh

# 4. View results
cat /tmp/rs300_test_log.txt | tail -30
```

---

## Step-by-Step Verification

### Step 1: Driver Loaded? (30 seconds after boot)
```bash
lsmod | grep rs300
```
✅ **Expected**: `rs300  49152  0`
❌ **If missing**: Check `dmesg | tail -50` for crash

### Step 2: No Crashes?
```bash
dmesg | grep -E "rs300.*Oops|rs300.*BUG|segmentation" | tail -20
```
✅ **Expected**: No output (no crashes)
❌ **If crash found**: STOP - report to Claude immediately

### Step 3: Camera Working?
```bash
v4l2-ctl -d /dev/v4l-subdev2 -C brightness
```
✅ **Expected**: `brightness: 50` (or any number)
❌ **If error**: Run `./configure_media.sh` manually

### Step 4: Run Full Tests
```bash
./test_consolidated_code.sh
```
✅ **Expected**: All 3 tests pass (FFC, colormap, brightness)
❌ **If failed**: Check `/tmp/rs300_test_log.txt`

---

## What to Report to Claude

**Case 1: SUCCESS** ✅
```
"All tests passed! Here's the summary:"
[paste last 20 lines from /tmp/rs300_test_log.txt]
```

**Case 2: CRASH ON BOOT** ❌
```
"Driver crashed during boot:"
[paste output from: dmesg | grep -A 30 "rs300.*Oops"]
```

**Case 3: LOADED BUT TESTS FAILED** ⚠️
```
"Driver loaded but test X failed:"
[paste output from: ./test_consolidated_code.sh]
```

---

## Expected Test Results (if working)

```
TEST 1: FFC Trigger
✓ FFC trigger command sent successfully

TEST 2: Colormap GET/SET
Current colormap: 0
Setting colormap to 3 (Ironbow)...
New colormap after SET: 3
✓ Colormap GET/SET verified correctly

TEST 3: Brightness GET/SET
Current brightness: 50
Setting brightness to 70...
New brightness after SET: 70
✓ Brightness GET/SET verified correctly

✓ No errors found in kernel logs
```

---

## Troubleshooting Quick Reference

| Issue | Command | Fix |
|-------|---------|-----|
| Driver not loaded | `sudo modprobe rs300` | If fails, check dmesg |
| Camera not configured | `./configure_media.sh` | Manual config |
| Test script missing | `ls test_consolidated_code.sh` | Should exist in driver dir |
| Permission denied | `chmod +x test_consolidated_code.sh` | Make executable |

---

**Ready to reboot!** After reboot, start with the QUICK START section above.
